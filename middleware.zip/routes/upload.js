const router = require("express").Router();

const upload = require("../middleware/upload");

const auth = require("../middleware/auth");

const controller = require("../controllers/uploadController");

router.post(
    "/csv",
    auth,
    upload.single("file"),
    controller.uploadCSV
);

router.post(
    "/excel",
    auth,
    upload.single("file"),
    controller.uploadExcel
);

module.exports = router;